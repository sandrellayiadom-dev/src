/* ============================================================
   SRC SPORTS ACADEMY – Main JavaScript
   ============================================================ */

$(document).ready(function () {

  /* ----------------------------------------------------------
     HAMBURGER MENU
  ---------------------------------------------------------- */
  $('.hamburger').on('click', function () {
    $(this).toggleClass('open');
    $('.mobile-menu').toggleClass('open');
    const expanded = $(this).hasClass('open');
    $(this).attr('aria-expanded', expanded);
  });

  // Close mobile menu on link click
  $('.mobile-menu a').on('click', function () {
    $('.hamburger').removeClass('open').attr('aria-expanded', false);
    $('.mobile-menu').removeClass('open');
  });

  // Close on outside click
  $(document).on('click', function (e) {
    if (!$(e.target).closest('.navbar, .mobile-menu').length) {
      $('.hamburger').removeClass('open').attr('aria-expanded', false);
      $('.mobile-menu').removeClass('open');
    }
  });

  /* ----------------------------------------------------------
     SEARCH FUNCTIONALITY (jQuery-based)
  ---------------------------------------------------------- */
  const pages = [
    { title: 'Home', url: 'index.html', keywords: 'home academy sports university' },
    { title: 'About Us', url: 'about.html', keywords: 'about mission vision values funding' },
    { title: 'Sports Programs', url: 'sports.html', keywords: 'football rugby ballet table tennis handball gymnastics programs' },
    { title: 'New Activities', url: 'new-activities.html', keywords: 'wrestling taekwondo judo volleyball new sports' },
    { title: 'Blog', url: 'blog.html', keywords: 'blog news updates events announcement coaches' },
    { title: 'Events', url: 'events.html', keywords: 'events schedule fixtures competitions attendance' },
    { title: 'Book Online', url: 'book.html', keywords: 'book booking training session online form' },
    { title: 'Register', url: 'register.html', keywords: 'register signup user account newsletter subscription' },
  ];

  function doSearch(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return pages.filter(p => p.title.toLowerCase().includes(q) || p.keywords.includes(q));
  }

  function renderResults(results, $container) {
    $container.empty();
    if (results.length === 0) {
      $container.append('<span class="no-results">No results found</span>');
    } else {
      results.forEach(r => {
        $container.append(`<a href="${r.url}">&#128269; ${r.title}</a>`);
      });
    }
    $container.show();
  }

  // Desktop search
  $('#nav-search-input').on('input', function () {
    const q = $(this).val().trim();
    const results = doSearch(q);
    if (q.length >= 2) renderResults(results, $('#search-results'));
    else $('#search-results').hide();
  });

  $('#nav-search-btn').on('click', function () {
    const q = $('#nav-search-input').val().trim();
    const results = doSearch(q);
    if (q.length >= 2) renderResults(results, $('#search-results'));
  });

  $(document).on('keydown', '#nav-search-input', function (e) {
    if (e.key === 'Escape') $('#search-results').hide();
  });

  // Mobile search
  $('#mobile-search-btn').on('click', function () {
    const q = $('#mobile-search-input').val().trim();
    const results = doSearch(q);
    if (results.length > 0) window.location.href = results[0].url;
  });

  // Hide search results on outside click
  $(document).on('click', function (e) {
    if (!$(e.target).closest('.nav-search').length) $('#search-results').hide();
  });

  /* ----------------------------------------------------------
     VISITOR COUNTER
  ---------------------------------------------------------- */
  function updateVisitorCounter() {
    let count = parseInt(localStorage.getItem('src_visitor_count') || '0', 10);
    // Increment on each page load (session-based)
    if (!sessionStorage.getItem('src_counted')) {
      count += 1;
      localStorage.setItem('src_visitor_count', count);
      sessionStorage.setItem('src_counted', 'true');
    }
    // Add a random base so it doesn't start from 1
    const display = count + 1247;
    $('#visitor-number').text(display.toLocaleString());
  }

  updateVisitorCounter();

  /* ----------------------------------------------------------
     ACTIVE NAV LINK
  ---------------------------------------------------------- */
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  $('.nav-links a, .mobile-menu a').each(function () {
    const href = $(this).attr('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      $(this).addClass('active');
    }
  });

  /* ----------------------------------------------------------
     SMOOTH SCROLL (anchors)
  ---------------------------------------------------------- */
  $('a[href^="#"]').on('click', function (e) {
    const target = $($(this).attr('href'));
    if (target.length) {
      e.preventDefault();
      $('html, body').animate({ scrollTop: target.offset().top - 80 }, 500);
    }
  });

  /* ----------------------------------------------------------
     FORM VALIDATION – Register Page
  ---------------------------------------------------------- */
  $('#register-form').on('submit', function (e) {
    e.preventDefault();
    let valid = true;

    // Clear previous errors
    $('.form-group').removeClass('has-error');
    $('.input-error').removeClass('input-error');

    const fields = ['reg-firstname', 'reg-lastname', 'reg-email', 'reg-dob', 'reg-sport'];
    fields.forEach(id => {
      const $input = $(`#${id}`);
      if (!$input.val().trim()) {
        $input.addClass('input-error');
        $input.closest('.form-group').addClass('has-error');
        valid = false;
      }
    });

    // Email format
    const email = $('#reg-email').val().trim();
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      $('#reg-email').addClass('input-error').closest('.form-group').addClass('has-error');
      valid = false;
    }

    // Password match
    const pw = $('#reg-password').val();
    const pw2 = $('#reg-password2').val();
    if (!pw || pw.length < 8) {
      $('#reg-password').addClass('input-error').closest('.form-group').addClass('has-error');
      valid = false;
    }
    if (pw !== pw2) {
      $('#reg-password2').addClass('input-error').closest('.form-group').addClass('has-error');
      valid = false;
    }

    // CAPTCHA check
    if (!$('#captcha-check').is(':checked')) {
      alert('Please complete the CAPTCHA verification.');
      valid = false;
    }

    if (valid) {
      $('#register-form').hide();
      $('#form-success').show();
      $('html, body').animate({ scrollTop: $('#form-success').offset().top - 100 }, 300);
    }
  });

  /* ----------------------------------------------------------
     FORM VALIDATION – Book Online Page
  ---------------------------------------------------------- */
  $('#book-form').on('submit', function (e) {
    e.preventDefault();
    let valid = true;

    $('.form-group').removeClass('has-error');
    $('.input-error').removeClass('input-error');

    const fields = ['book-name', 'book-email', 'book-phone', 'book-sport', 'book-date', 'book-time'];
    fields.forEach(id => {
      const $input = $(`#${id}`);
      if (!$input.val().trim()) {
        $input.addClass('input-error');
        $input.closest('.form-group').addClass('has-error');
        valid = false;
      }
    });

    // Email
    const email = $('#book-email').val().trim();
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      $('#book-email').addClass('input-error').closest('.form-group').addClass('has-error');
      valid = false;
    }

    // CAPTCHA
    if (!$('#book-captcha').is(':checked')) {
      alert('Please verify you are not a robot.');
      valid = false;
    }

    if (valid) {
      $('#book-form').hide();
      $('#book-success').show();
      $('html, body').animate({ scrollTop: $('#book-success').offset().top - 100 }, 300);
    }
  });

  /* ----------------------------------------------------------
     FORUM / Q&A (New Activities Page)
  ---------------------------------------------------------- */
  $('#forum-form').on('submit', function (e) {
    e.preventDefault();
    const name = $('#forum-name').val().trim();
    const msg = $('#forum-message').val().trim();
    if (!name || !msg) return;

    const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 2);
    const now = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

    const $post = $(`
      <div class="forum-post">
        <div class="forum-post-header">
          <div class="avatar">${initials}</div>
          <div class="forum-post-meta">
            <strong>${name}</strong>
            <span>Just now &middot; ${now}</span>
          </div>
        </div>
        <p>${msg}</p>
      </div>
    `);

    $('#forum-posts').prepend($post);
    $(this)[0].reset();
    $post.hide().slideDown(300);
  });

  /* ----------------------------------------------------------
     NEWSLETTER (Footer)
  ---------------------------------------------------------- */
  $('.newsletter-form').on('submit', function (e) {
    e.preventDefault();
    const $input = $(this).find('input');
    const email = $input.val().trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      $input.css('border-color', '#e63946');
      return;
    }
    $(this).find('button').text('Subscribed! ✓').prop('disabled', true);
    $input.val('').prop('disabled', true).css('border-color', '#22c55e');
  });

  /* ----------------------------------------------------------
     SCROLL ANIMATIONS (fade-in)
  ---------------------------------------------------------- */
  const $animEls = $('.card, .sport-card, .event-card, .blog-card, .value-card, .new-activity-card');

  function checkInView() {
    const windowBottom = $(window).scrollTop() + $(window).height();
    $animEls.each(function () {
      if ($(this).offset().top < windowBottom - 60) {
        $(this).addClass('in-view');
      }
    });
  }

  // Add CSS for animation
  $('<style>')
    .text('.card,.sport-card,.event-card,.blog-card,.value-card,.new-activity-card{opacity:0;transform:translateY(24px);transition:opacity 0.5s ease,transform 0.5s ease;}.card.in-view,.sport-card.in-view,.event-card.in-view,.blog-card.in-view,.value-card.in-view,.new-activity-card.in-view{opacity:1;transform:translateY(0);}')
    .appendTo('head');

  $(window).on('scroll', checkInView);
  checkInView(); // run on load

});
